
var MAIN_HELP_PAGE = "index.html";
var g_d2hContextIds = new Array();
